﻿using System;
using System.Collections.Generic;

namespace Sequrites1
{
    public partial class Operation
    {
        public int Id { get; set; }
        public int? Dealid { get; set; }
        public int? Subaccountid { get; set; }
        public int? Number { get; set; }
        public DateTime? Date { get; set; }
        public string? Type { get; set; }
        public double? Sum { get; set; }
        public double? Saldoinput { get; set; }
        public double? Saldooutput { get; set; }

        public virtual Deal? Deal { get; set; }
        public virtual Subaccount? Subaccount { get; set; }
    }
}
