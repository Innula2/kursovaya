﻿using Sequrites1.View;
using System;
using System.Collections.Generic;

namespace Sequrites1
{
    public partial class Subaccount
    {
        public Subaccount()
        {
            Operations = new HashSet<Operation>();
        }

        public int Id { get; set; }
        public int? Accountplanid { get; set; }
        public string? Name { get; set; }
        public double? Number { get; set; }

        public virtual Accountplan? Accountplan { get; set; }
        public virtual ICollection<Operation> Operations { get; set; }

        public static implicit operator Subaccount(SubAccount v)
        {
            throw new NotImplementedException();
        }
    }
}
