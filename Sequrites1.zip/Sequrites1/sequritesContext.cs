﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Sequrites1
{
    public partial class sequritesContext : DbContext
    {
        public sequritesContext()
        {
        }

        public sequritesContext(DbContextOptions<sequritesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Accountplan> Accountplans { get; set; } = null!;
        public virtual DbSet<Deal> Deals { get; set; } = null!;
        public virtual DbSet<Operation> Operations { get; set; } = null!;
        public virtual DbSet<Subaccount> Subaccounts { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=innusik\\sqlexpress;Database=sequrites;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Accountplan>(entity =>
            {
                entity.ToTable("accountplan");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Number).HasColumnName("number");
            });

            modelBuilder.Entity<Deal>(entity =>
            {
                entity.ToTable("deal");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Agreement).HasColumnName("agreement");

                entity.Property(e => e.Commission).HasColumnName("commission");

                entity.Property(e => e.Date)
                    .HasColumnType("datetime")
                    .HasColumnName("date");

                entity.Property(e => e.NumberDeal).HasColumnName("number_deal");

                entity.Property(e => e.OrderDeal).HasColumnName("order_deal");

                entity.Property(e => e.Price).HasColumnName("price");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.Tiker)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("tiker");

                entity.Property(e => e.Totalcost).HasColumnName("totalcost");

                entity.Property(e => e.Trader)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("trader");
            });

            modelBuilder.Entity<Operation>(entity =>
            {
                entity.ToTable("operation");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Date)
                    .HasColumnType("datetime")
                    .HasColumnName("date");

                entity.Property(e => e.Dealid).HasColumnName("dealid");

                entity.Property(e => e.Number).HasColumnName("number");

                entity.Property(e => e.Saldoinput).HasColumnName("saldoinput");

                entity.Property(e => e.Saldooutput).HasColumnName("saldooutput");

                entity.Property(e => e.Subaccountid).HasColumnName("subaccountid");

                entity.Property(e => e.Sum).HasColumnName("sum");

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("type");

                entity.HasOne(d => d.Deal)
                    .WithMany(p => p.Operations)
                    .HasForeignKey(d => d.Dealid)
                    .HasConstraintName("FK_operation_deal");

                entity.HasOne(d => d.Subaccount)
                    .WithMany(p => p.Operations)
                    .HasForeignKey(d => d.Subaccountid)
                    .HasConstraintName("FK_operation_subaccount");
            });

            modelBuilder.Entity<Subaccount>(entity =>
            {
                entity.ToTable("subaccount");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Accountplanid).HasColumnName("accountplanid");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Number).HasColumnName("number");

                entity.HasOne(d => d.Accountplan)
                    .WithMany(p => p.Subaccounts)
                    .HasForeignKey(d => d.Accountplanid)
                    .HasConstraintName("FK_subaccount_accountplan");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
