﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Sequrites1.View;

namespace Sequrites1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DbContextOptions<sequritesContext> options;

        
        ObservableCollection<Accountplan> accountplans = new ObservableCollection<Accountplan>();
        ObservableCollection<Operation> operations = new ObservableCollection<Operation>();
        ObservableCollection<Subaccount> subaccounts = new ObservableCollection<Subaccount>();
        ObservableCollection<Deal> deals = new ObservableCollection<Deal>();
        public MainWindow()
        {
            InitializeComponent();

            var builder = new ConfigurationBuilder();
            // установка пути к текущему каталогу
            builder.SetBasePath(Directory.GetCurrentDirectory());
            // получаем конфигурацию из файла appsettings.json
            builder.AddJsonFile("appsettings.json");
            // создаем конфигурацию
            IConfigurationRoot? config = builder.Build();
            // получаем строку подключения
            string connectionString = config.GetConnectionString("DefaultConnection");

            var optionsBuilder = new DbContextOptionsBuilder<sequritesContext>();
            options = optionsBuilder.UseSqlServer(connectionString).Options;
           
        }
        private async void btLoad_Click(object sender, RoutedEventArgs e)
        {
            

            ProgressBarCar.Visibility = Visibility.Visible;


            Task tc = Task.Run(() =>
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    var query = db.Accountplans;
                    if (query.Count() != 0)
                    {
                        foreach (var c in query)
                           accountplans.Add(c);
                    }
                }
            });

            await tc;

            await Task.Run(() => Thread.Sleep(200));

            ProgressBarCar.Visibility = Visibility.Collapsed;
            lvCar.ItemsSource = accountplans;
        }
        private void btAdd_Click(object sender, RoutedEventArgs e)
        {
            Accountplan newAccountplan = new Accountplan();
            AccountPlan editAccountPlan = new AccountPlan();
            editAccountPlan.Title = "Добавление нового плана счетов";
            editAccountPlan.DataContext = newAccountplan;
            editAccountPlan.ShowDialog();

            if (editAccountPlan.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    try
                    {
                        db.Accountplans.Add(newAccountplan);
                        db.SaveChanges();
                        accountplans.Add(newAccountplan);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка добавления данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btEdit_Click(object sender, RoutedEventArgs e)
        {
            Accountplan editPlan = (Accountplan)lvCar.SelectedItem;

            AccountPlan editAccountPlan = new AccountPlan();
            editAccountPlan.Title = "Редактирование данных плана счетов";
            editAccountPlan.DataContext = editPlan;
            editAccountPlan.ShowDialog();



            if (editAccountPlan.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    Accountplan accountplan = db.Accountplans.Find(editPlan.Id);
                    if (accountplan.Name != editPlan.Name)
                        accountplan.Name = editPlan.Name.Trim();
                    //if (accountplan.Number != editPlan.Number)
                    //    accountplan.Number = editPlan.Number.Trim(); 

                    try
                    {
                        db.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка редактирования данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btDelete_Click(object sender, RoutedEventArgs e)
        {
            Accountplan delAccountplan = (Accountplan)lvCar.SelectedItem;

            using (sequritesContext db = new sequritesContext(options))
            {
                // Поиск в контексте удаляемого 
                Accountplan delPlan = db.Accountplans.Find(delAccountplan.Id);

                if (delPlan != null)
                {
                    MessageBoxResult result = MessageBox.Show("Удалить данные по клиенту: \n" + delPlan.Name + "  " + delPlan.Number,
                  "Предупреждение", MessageBoxButton.OKCancel);
                    if (result == MessageBoxResult.OK)
                    {
                        try
                        {
                            db.Accountplans.Remove(delPlan);
                            db.SaveChanges();
                            accountplans.Remove(delAccountplan);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("\nОшибка удаления данных!\n" + ex.Message, "Предупреждение");
                        }
                    }
                }
            }

        }

        private async void btLoadSub_Click(object sender, RoutedEventArgs e)
        {
          

            ProgressBarSubaccount.Visibility = Visibility.Visible;

            Task tc = Task.Run(() =>
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    var query = db.Subaccounts
                    .Include(c => c.Accountplan);
                    if (query.Count() != 0)
                    {
                        foreach (var o in query)
                            subaccounts.Add(o);
                    }
                }
            });

            await tc;

            await Task.Run(() => Thread.Sleep(200));

            ProgressBarSubaccount.Visibility = Visibility.Collapsed;
            lvSubaccount.ItemsSource = subaccounts;
        }
        private void btAddSub_Click(object sender, RoutedEventArgs e)
        {
            Subaccount newSubaccount = new Subaccount();
            SubAccount editSubAccount = new SubAccount();
            editSubAccount.Title = "Добавление нового плана счетов";
            editSubAccount.DataContext = newSubaccount;
            editSubAccount.ShowDialog();
           
           

            if (editSubAccount.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {

                    try
                    {
                        db.Subaccounts.Add(newSubaccount);
                        db.SaveChanges();
                        subaccounts.Add(newSubaccount);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка добавления данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btEditSub_Click(object sender, RoutedEventArgs e)
        {
            Subaccount editSub = (Subaccount)lvSubaccount.SelectedItem;

            SubAccount editSubAccount = new SubAccount();
            editSubAccount.Title = "Редактирование данных плана счетов";
            editSubAccount.DataContext = editSub;
            editSubAccount.ShowDialog();


            if (editSubAccount.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    Subaccount subaccount = db.Subaccounts.Find(editSub.Id);
                    if (subaccount.Name != editSub.Name)
                        subaccount.Name = editSub.Name.Trim();
                    //if (accountplan.Number != editPlan.Number)
                    //    accountplan.Number = editPlan.Number.Trim(); разобраться с Int

                    try
                    {
                        db.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка редактирования данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btDeleteSub_Click(object sender, RoutedEventArgs e)
        {
            Subaccount delSubaccount = (Subaccount)lvSubaccount.SelectedItem;

            using (sequritesContext db = new sequritesContext(options))
            {
                // Поиск в контексте удаляемого 
                Subaccount delSub = db.Subaccounts.Find(delSubaccount.Id);

                if (delSub != null)
                {
                    MessageBoxResult result = MessageBox.Show("Удалить данные по клиенту: \n" + delSub.Name + "  " + delSub.Number,
                  "Предупреждение", MessageBoxButton.OKCancel);
                    if (result == MessageBoxResult.OK)
                    {
                        try
                        {
                            db.Subaccounts.Remove(delSub);
                            db.SaveChanges();
                            subaccounts.Remove(delSubaccount);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("\nОшибка удаления данных!\n" + ex.Message, "Предупреждение");
                        }
                    }
                }
            }

        }


        private async void btLoadDeal_Click(object sender, RoutedEventArgs e)
        {

            ProgressBarDeal.Visibility = Visibility.Visible;


            Task tc = Task.Run(() =>
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    var query = db.Deals;
                    if (query.Count() != 0)
                    {
                        foreach (var c in query)
                            deals.Add(c);
                    }
                }
            });

            await tc;

            await Task.Run(() => Thread.Sleep(200));

            ProgressBarDeal.Visibility = Visibility.Collapsed;
            lvDeal.ItemsSource = deals;
        }


        private void btAddDeal_Click(object sender, RoutedEventArgs e)
        {
            Deal newDeal = new Deal();
            DealView editDealView = new DealView();
            editDealView.Title = "Добавление новой сделки";
            editDealView.DataContext = newDeal;
            editDealView.ShowDialog();

            if (editDealView.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    try
                    {
                        db.Deals.Add(newDeal);
                        db.SaveChanges();
                        deals.Add(newDeal);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка добавления данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }
        }

        private void btEditDeal_Click(object sender, RoutedEventArgs e)
        {
           Deal editDeal = (Deal)lvDeal.SelectedItem;
           

            DealView editDealView = new DealView();
            editDealView.Title = "Редактирование данных новой сделки";
            editDealView.DataContext = editDeal;
            editDealView.ShowDialog();



            if (editDealView.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    Deal deal = db.Deals.Find(editDeal.Id);
                    if (deal.Tiker != editDeal.Tiker)
                        deal.Tiker = editDeal.Tiker.Trim();
                    //if (accountplan.Number != editPlan.Number)
                    //    accountplan.Number = editPlan.Number.Trim(); разобраться с Int

                    try
                    {
                        db.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка редактирования данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btDeleteDeal_Click(object sender, RoutedEventArgs e)
        {
            Deal delDeal = (Deal)lvDeal.SelectedItem;

            using (sequritesContext db = new sequritesContext(options))
            {
                // Поиск в контексте удаляемого 
                Deal delD = db.Deals.Find(delDeal.Id);

                if (delD != null)
                {
                    MessageBoxResult result = MessageBox.Show("Удалить данные по клиенту: \n" + delD.Agreement + "  " + delD.Tiker + "  " + delD.OrderDeal + "  " + delD.NumberDeal + "  " + delD.Date + "  " + delD.Quantity + "  " + delD.Price + "  " + delD.Totalcost,
                  "Предупреждение", MessageBoxButton.OKCancel);
                    if (result == MessageBoxResult.OK)
                    {
                        try
                        {
                            db.Deals.Remove(delD);
                            db.SaveChanges();
                            deals.Remove(delDeal);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("\nОшибка удаления данных!\n" + ex.Message, "Предупреждение");
                        }
                    }
                }
            }

        }
        private async void btLoadOperation_Click(object sender, RoutedEventArgs e)
        {


            ProgressBarOperation.Visibility = Visibility.Visible;

            Task tc = Task.Run(() =>
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    var query = db.Operations
                    .Include(c => c.Deal)
                    .Include(c => c.Subaccount);
                    if (query.Count() != 0)
                    {
                        foreach (var o in query)
                            operations.Add(o);
                    }
                }
            });

            await tc;

            await Task.Run(() => Thread.Sleep(200));

            ProgressBarOperation.Visibility = Visibility.Collapsed;
            lvOperation.ItemsSource = operations;
        }

        private void btAddOperation_Click(object sender, RoutedEventArgs e)
        {
           
            Operation newOperation = new Operation();
            OperationView editOperationView = new OperationView();
            editOperationView.Title = "Добавление новой операции";
            editOperationView.DataContext = newOperation;
            editOperationView.ShowDialog();
          

            if (editOperationView.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    try
                    {
                        var query = db.Operations
                   .Include(c => c.Deal)
                   .Include(c => c.Subaccount);
                        db.Operations.Add(newOperation);
                        db.SaveChanges();
                        operations.Add(newOperation);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка добавления данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btEditOperation_Click(object sender, RoutedEventArgs e)
        {
            Operation editOperation = (Operation)lvOperation.SelectedItem;


            OperationView editOperationView = new OperationView();
            editOperationView.Title = "Редактирование данных операций";
            editOperationView.DataContext = editOperation;
            editOperationView.ShowDialog();



            if (editOperationView.DialogResult == true)
            {
                using (sequritesContext db = new sequritesContext(options))
                {
                    Operation operation = db.Operations.Find(editOperation.Id);
                    if (operation.Type != editOperation.Type)
                        operation.Type = editOperation.Type.Trim();
                    //if (accountplan.Number != editPlan.Number)
                    //    accountplan.Number = editPlan.Number.Trim(); разобраться с Int

                    try
                    {
                        db.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("\nОшибка редактирования данных!\n" + ex.Message, "Предупреждение");
                    }
                }
            }

        }

        private void btDeleteOperation_Click(object sender, RoutedEventArgs e)
        {
            Operation delOperation = (Operation)lvOperation.SelectedItem;

            using (sequritesContext db = new sequritesContext(options))
            {
                // Поиск в контексте удаляемого 
                Operation delO = db.Operations.Find(delOperation.Id);

                if (delO != null)
                {
                    MessageBoxResult result = MessageBox.Show("Удалить данные по операции: \n" /*+ delO.Deal.Tiker + "  " + delO.Subaccount.Name + "  " */+ delO.Number + "  " + delO.Date + "  " + delO.Type + "  " + delO.Sum + "  " + delO.Saldoinput + "  " + delO.Saldooutput,
                  "Предупреждение", MessageBoxButton.OKCancel);
                    if (result == MessageBoxResult.OK)
                    {
                        try
                        {
                            db.Operations.Remove(delO);
                            db.SaveChanges();
                            operations.Remove(delOperation);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("\nОшибка удаления данных!\n" + ex.Message, "Предупреждение");
                        }
                    }
                }
            }

        }


    }
}
